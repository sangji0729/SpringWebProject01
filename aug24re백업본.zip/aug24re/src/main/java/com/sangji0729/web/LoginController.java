package com.sangji0729.web;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.sangji0729.util.Util;
import com.sangji0729.web.login.LoginDTO;
import com.sangji0729.web.login.LoginService;

@Controller
public class LoginController {
	@Autowired
	private LoginService loginService;
	@Autowired
	private LogService logService;
	@Autowired
	private Util util;
	/*
	 * 화면 만들기
	 * 데이터받기
	 * 데이터베이스에 질의하기
	 * 결과 판별하기
	 * 세션만들기
	 * 페이지이동
	 */
	
	@GetMapping("/login")
	public String login() {
		return "login";
		//http://localhost:8080/web/login
	}
	
	//로그인
	@PostMapping("/login")
	public String loginAction(HttpServletRequest request) {
		//데이터베이스 보내고 
		//올바른 로그인이면 세션 만들어서 -> board
		//잘못된 로그인이면 로그인페이지로 -> login
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		//System.out.println("id : " + id + " pw : " + pw);
		
		
		//LoginDTO 만들기
		LoginDTO dto = new LoginDTO();
		dto.setSm_id(id);
		dto.setSm_pw(pw);
		
		//service -> DAO -> mapper.xml
		LoginDTO result = loginService.login(dto);	
		System.out.println(result);//객체
		
		if(result != null) {//정상 로그인
			//세션은 여기에
			HttpSession session = request.getSession();
			session.setAttribute("sm_name", result.getSm_name());
			session.setAttribute("sm_id", result.getSm_id());
			System.out.println(id);
			System.out.println(pw);
			
			String ip = util.getUserIp(request);
			String target = id;
			String data = "로그인";
			LogDTO logDTO = new LogDTO(ip, target, data, id);
			logService.writeLog(logDTO);
			return "redirect:/board";	
			
		}else {//비정상 로그인
			return "redirect:/?error=loginError";
			
		}
		
	}
	
	//로그아웃
	@GetMapping("/logout")
	public String logout(HttpServletRequest request) {
		HttpSession session = request.getSession();
		String id = (String)session.getAttribute("sm_id");
		String ip = util.getUserIp(request);
		String target = id;
		String data = "로그인";
		
		
		if(session.getAttribute("sm_id") != null ) {
			session.removeAttribute("sm_id");			
		}
		if(session.getAttribute("sm_name") != null) {
			session.removeAttribute("sm_name");
		}
		// index로 가도록 수정
		return "redirect:/";
	}
	
	//가입하기
	@GetMapping("/join")
	public String join(HttpServletRequest request) {
		return "join";
	}
	
	@PostMapping("/join")
	public String joinAction(HttpServletRequest request) {
		//오는데이터 잡기
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		//String pw2 = request.getParameter("pw2");
		String name = request.getParameter("name");
		String email = request.getParameter("email");
		
		//System.out.println("id : " + id);
		//System.out.println("pw1 : " + pw);
		//System.out.println("pw2 : " + pw2);
		//System.out.println("name : " + name);
		//System.out.println("email : " + email);
		
		Map<String, Object> login = new HashMap<String, Object>();
		login.put("id", id);
		login.put("pw", pw);
		login.put("name", name);
		login.put("email", email);
		
		int result = loginService.join(login);
		System.out.println("저장 결과 : " + result);
		
		return "redirect:/";
	}
	
	//ajax id check
	@PostMapping("/checkID")
	public @ResponseBody String checkID(HttpServletRequest request) {
		String id = request.getParameter("id");
		System.out.println("들어온 ID는 : "+ id);
		String check = "1";
		//데이터베이스에게 질의하기
		check = loginService.checkID(id);
		return check;
	}
	
	
}
