package com.sangji0729.web;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.sangji0729.util.Util;
import com.sangji0729.web.admin.AdminService;
import com.sangji0729.web.admin.MemberDTO;

import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;

/*
 * 2021-08-25 testController
 * 
 * user -> RD -> Controller -> Service -> DAO -> mybatis -> DB 
 * 				 DTO(VO)
 * user <------  View(jsp)
 * 
 * 
데이터 통신 user => Controller -> Service -> DAO -> DB
1. pom.xml에 관련 maven을 다 입력한다.
2. src/main/resources에 spring, mybatis(mappers, config)을 생성한다
3. spring에 data-context.xml을 생성하고 sqlSession 설정 및 dataSource 객체를 생성한다.
4. mybatisConfig에 내가 만든 클래스를 mybatis가 사용할 수 있도록 등록해준다.(TestDTO)
5. testMapper에 sql문을 생성한다. id는 boardList로 resultType은 TestDTO로 만든다. 그리고 해당 sql문을 갖고 있는 mapper이름을 test라고 지정한다.
6. TestDTO를 생성한다. getter와 setter를 설정한다.
7. TestDAO를 생성한다. 실제 데이터를 불러오도록 한다. sqlSession을 이용하여 test속 boardList라고 생성된 sql문을 통해 데이터베이스와 통신한다.
8. TestService.java를 생성하고 데이터베이스와 통신한 후 받아온 값을 담아준다.
9. TestController.java에서  맵핑작업(어느 페이지에 대한 컨트롤러인지)을 해주고, TestService.java에 있는 boardList를 잡아 ModelAndView에 데이터를 리스트로 담아서 반환값으로 지정해줍니다.
10. board.jsp에서 컨트롤러에서 받은 값을 표현해줍니다.

 * 
 */
@Controller
public class TestController {
	@Autowired
	private TestService testService;
	@Autowired
	private AdminService adminService;
	@Autowired
	private LogService logService;
	@Autowired
	private Util util;
	
	@RequestMapping("/menu")
	public ModelAndView menu() {
		
		ModelAndView mv = new ModelAndView("menu");
		List<HashMap<String, Object>> categoryList = testService.categoryList();
		mv.addObject("categoryList",categoryList);
		return mv;
	}
	
	// 맵핑작업
	@RequestMapping(value = "/board", method = RequestMethod.GET)
	public ModelAndView board(HttpServletRequest request) {
		ModelAndView mv = new ModelAndView("board");//jsp
		HttpSession session = request.getSession();
		//ip불러오기
		String ip = util.getUserIp(request);
		String searchName = request.getParameter("searchName");
		String search = request.getParameter("search");
		//System.out.println("ip는 : " + ip);
		//System.out.println("searchName : " + request.getParameter("searchName"));
		//System.out.println("search : " + request.getParameter("search"));
		
		String target = "board";
		String data = "게시판 접근";
		String id = (String) session.getAttribute("sm_id");
		
		LogDTO dto = null;
		
		
		
		int sb_cate = 1;
		if(request.getParameter("sb_cate") != null &&
				util.str2Int(request.getParameter("sb_cate"))) {
			sb_cate =  util.str2Int2(request.getParameter("sb_cate"));
		}
		//데이터베이스로 보낼 map만들기
		Map<String, Object> sendMap = new HashMap<String, Object>();
		sendMap.put("sb_cate", sb_cate);
		sendMap.put("search", search);
		sendMap.put("searchName", searchName);
		
		
		
		//페이지네이션인포 만들기
		PaginationInfo paginationInfo = new PaginationInfo();
		int pageNo = 1;
		int listScale = 10;// 한 페이지에 나올 글 수
		int pageScale = 10;// 페이지 갯수
		
		if(request.getParameter("pageNo") != null) {
			pageNo = util.str2Int2(request.getParameter("pageNo"));
		}
		
		paginationInfo.setCurrentPageNo(pageNo);
		paginationInfo.setRecordCountPerPage(listScale);
		paginationInfo.setPageSize(pageScale);
		
		int startPage = paginationInfo.getFirstRecordIndex();//시작 페이지
		int lastPage = paginationInfo.getRecordCountPerPage();//마지막 페이지
		
		sendMap.put("startPage", startPage);
		sendMap.put("lastPage", lastPage);
		
		//System.out.println("들어온 카테고리 : " + sb_cate);
		//데이터베이스에 접근해서 값 가져오고 DTO(VO)/DAO SERVICE 그 값을 mv에 붙이고 board에 찍어주기
		//user -> Controller -> Service -> DAO -> DB
		//						DTO(VO)에 담아서 보내줍니다
		
		//Service에게 일 시키기
		//보드 리스트 가져오기
		List<TestDTO> boardList = testService.boardList(sendMap);
		//카테고리 리스트 가져오기
		//List<HashMap<String, Object>> categoryList = testService.categoryList();
		//카테고리 찍기
		//String category = testService.getCategory(sb_cate);
		
		/*
		 * String category = (String) categoryList.get(0).get("sc_category"); for
		 * (HashMap<String, Object> list : categoryList) { Object cateNo =
		 * list.get("sc_no");//이렇게 추가해두조 ㅠㅠㅠ if(cateNo.equals(sb_cate)) {//이부분 수정해야합니다.
		 * category = (String) list.get("sc_category"); } }
		 */

		int totalList = testService.totalList(sb_cate);
		
		paginationInfo.setTotalRecordCount(totalList);//전체 글 수 저장
		mv.addObject("paginationInfo", paginationInfo);//페이징도 보내기
		mv.addObject("pageNo", pageNo);//현 페이지 번호
		mv.addObject("totalList", totalList);//전체 글 수
		
		
		
		mv.addObject("list", boardList);
		mv.addObject("category", boardList.get(0).getSc_category());
		//mv.addObject("categoryList", categoryList);//새로 추가된 카테고리 리스트
		mv.addObject("sb_cate", sb_cate);
		//board에 찍어주기
		
		if(session.getAttribute("sm_id") != null) {
			dto = new LogDTO(ip, target, data, id);
		}else {
			dto = new LogDTO(ip, target, data);			
		}
		
		logService.writeLog(dto);
		
		return mv;
	}
	
	//write 글쓰기 맵핑작업
	//@RequestMapping(value = "/write" , method = RequestMethod.GET)
	@GetMapping("/write")
	public String write(HttpServletRequest request) {
		//위에서 잡은 sb_cate를 MV에 붙여서 write.jsp로 보내기
		//그럼 form태그 안에서 붙여서 글쓰기 버튼을 눌렀을때 
		//sb_cate값까지 가져갈 수 있음.
		//로그인 한 사람 확인
		
		HttpSession session = request.getSession();
		
		if(session.getAttribute("sm_name") != null && session.getAttribute("sm_id") != null) {
			return "write";	//정상 로그인시 글쓰기 화면으로
		}else {
			return "redirect:/"; // 비로그인시 로그인화면으로
		}
	}
	@PostMapping("/write")
	public String write2(TestDTO testDTO, HttpServletRequest request) {
		//session에 있는 id값 넣어주기
		HttpSession session = request.getSession();
		
		//로그
		String ip = util.getUserIp(request);
		String target = "board";
		String data = "게시글 작성";
		String id = (String) session.getAttribute("sm_id");
		
		
		
		
		
		
		if(session.getAttribute("sm_name") != null && session.getAttribute("sm_id") != null) {
			//정상 로그인
			testDTO.setSm_id((String) session.getAttribute("sm_id"));//id는 세션으로 올릴 예정이기 때문에
			//testDTO.setSb_cate(1);//1번 카테고리(자유게시판)으로 보내기
			
			/*
			 * System.out.println("제목 : " + testDTO.getSb_title());
			 * System.out.println("내용 : " + testDTO.getSb_content());
			 * System.out.println("카테고리"+testDTO.getSb_cate());
			 */
			//no넣어주기
			//testDTO.setNo(3);
			LogDTO logDTO = new LogDTO(ip, target, data, id);
			logService.writeLog(logDTO);
			
			
			//service -> dao -> mybatis -> DB
			testService.write(testDTO);
			return "redirect:/board?sb_cate=" + testDTO.getSb_cate();//board메소드 다시 실행
			
		}else {
			// 비정상 로그인
			return "redirect:/";
		}
		//@RequestParam("title") String title, @RequestParam("content") String content
		//String title = request.getParameter("title");
		//String content = request.getParameter("content");
		
		
	}
	//@RequestMapping(value="/test", method= {RequestMethod.GET, RequestMethod.POST)
	//@RequestMappint(value="/test")
	
	@GetMapping("/detail")
	public ModelAndView detail(@RequestParam("sb_no") int sb_no) {
		//조회수 처리
		testService.viewCount(sb_no);
		//HashMap<String, Object> map = testService.
		//System.out.println("bno : " + bno);
		
		//데이터베이스에서 값 가져오기
		//SELECT * FROM boardview WHERE bno=?
		//TestDTO 
		TestDTO dto = testService.detail(sb_no);
		//MV
		ModelAndView mv = new ModelAndView("detail");
		//값 붙이기
		mv.addObject("dto", dto);
		
		
		
		return mv;
	}
	
	@GetMapping("/delete")
	public String delete(@RequestParam("sb_no") int sb_no, HttpServletRequest request) {
		HttpSession session = request.getSession();
		String ip = util.getUserIp(request);
		String id = (String) session.getAttribute("sm_id");
		String target = "board";
		String data = "게시글 삭제";
		
		LogDTO logDTO = null;
		
		if(session.getAttribute("sm_id") != null) {
			logDTO = new LogDTO(ip, target, data, id);
		}else {
			logDTO = new LogDTO(ip, target, data);
		}
				
		logService.writeLog(logDTO);
				
		//데이터베이스로 sb_no보내기
		int result = testService.delete(sb_no);
		System.out.println("결과 : " + result);
		
		return "redirect:/board"; //sb_cate받아서 해당 경로로 이동하기			
	}
	
	@GetMapping("/update")
	public ModelAndView update(HttpServletRequest request) {
		ModelAndView mv = new ModelAndView("update");
		int sb_no = Integer.parseInt(request.getParameter("sb_no"));
		System.out.println("bno : " + sb_no);
		
		TestDTO dto = testService.detail(sb_no);
		
		mv.addObject("dto", dto);
		
		return mv;
	}
	
	@PostMapping("update")
	public String update(TestDTO dto) {//name이 똑같다면 거기에 저장
		/*
		 * System.out.println(dto.getBtitle()); 
		 * System.out.println(dto.getBcontent());
		 * System.out.println(dto.getBno());
		 */
		
		//데이터베이스로 보내서 저장
		int result = testService.update(dto);
		System.out.println("수정결과 : " + result);
		
		return "redirect:/detail?sb_no=" + dto.getSb_no();
	}
	
	@RequestMapping("/temp")
	public String temp() {
		
		return "temp";
	}
	
	@GetMapping("/member")
	public String member() {
		
		return "redirect:/admin/member";
	}
	
	@GetMapping("/memberList")
	public ModelAndView memberList() {
		ModelAndView mv = new ModelAndView();
		List<MemberDTO> list = (List<MemberDTO>)adminService.list();
		mv.addObject("list", list);
		
		return mv;
	}
	
	@RequestMapping("/like")
	public String like(@RequestParam("sb_no") int sb_no, HttpServletRequest request) {
		//System.out.println(request.getParameter("sb_no"));
		HttpSession session = request.getSession();
		//System.out.println(session.getAttribute("sm_id"));
		
		if(session.getAttribute("sm_id") != null) {
			//보낼 값이 2개 sb_no, sm_id
			Map<String, Object> sendMap = new HashMap<String, Object>();
			String id = (String)session.getAttribute("sm_id");
			sendMap.put("sb_no", sb_no);
			sendMap.put("sm_id", id);
			
			
			testService.like(sendMap);
			return "redirect:/detail?sb_no="+sb_no;
		}else {
			return "redirect:/";
		}
		//System.out.println(result + " 추천완료");
		
		
	}
	
}
